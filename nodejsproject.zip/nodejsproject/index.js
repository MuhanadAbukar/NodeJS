const http = require('http')
const path = require('path')
const fs = require('fs')
const fsPromises = require('fs').promises
const mime = require("mime-types");

const PORT = process.env.PORT || 3501

const serveFile = async (filePath, contentType, response) => {
    try {
        // Read file content
        const rawData = await fsPromises.readFile(filePath, contentType.includes('image') ? '' : 'utf8');
        let data;
        // Parse json if necessary
        if (contentType === 'application/json') {
            data = JSON.stringify(JSON.parse(rawData));
        } else {
            data = rawData;
        }
        let statusCode = 200;
        // Set status code to 404 if file is 404.html
        if (filePath.includes('404.html')) {
            statusCode = 404;
        }
        // Set response headers
        response.writeHead(statusCode, {
            'Content-Type': contentType
        });
        // Send response
        response.end(data);
    } catch (err) {
        console.log(err);
        response.statusCode = 500;
        response.end();
    }
}

const server = http.createServer((req, res) => {

    // Get file extension
    const extension = path.extname(req.url);
    let contentType = mime.lookup(extension);
    let filePath;
    // Set filepath for index.html
    if (contentType === 'text/html' && req.url === '/') {
        filePath = path.join(__dirname, 'views', 'index.html');
    } 
    // Set filepath for subdirectories' index.html
    else if (contentType === 'text/html' && req.url.slice(-1) === '/') {
        filePath = path.join(__dirname, 'views', req.url, 'index.html');
    } 
    // Set filepath for other html pages
    else if (contentType === 'text/html') {
        filePath = path.join(__dirname, 'views', req.url);
    } 
    // Set filepath for other files
    else {
        filePath = path.join(__dirname, req.url);
    }
    
    if (!extension && req.url.slice(-1) !== '/') {
        filePath += '.html'
    }
    const fileExists = fs.existsSync(filePath);
    if (fileExists) {
        serveFile(filePath, contentType, res);
    } 
    else {
        // Serve 404 page
        serveFile(path.join(__dirname, 'views', '404.html'), 'text/html', res)
    }
});

server.listen(PORT, () => console.log(`Server running on port ${PORT}`))